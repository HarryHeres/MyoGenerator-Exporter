'''
Strings for different props
'''
props = {
    "DecomposeButton_type_specified" : "specified",
    "DecomposeButton_type_all" : "all",
}