'''
Strings as bl_idnames of each elements
'''
ids = {
    "MainPanel_bl_idname" : "exporter.main_panel",
    "MirrorMenu_bl_idname" : "exporter.mirror_menu",
    "ExportButton_bl_idname" : "object.export_coords",
    "DecomposeButton_bl_idname" : "object.decompose",
    "FlipButton_bl_idname" : "object.flip",
    "ProgressPopup_bl_idname" : "exporter.ok_popup",
}